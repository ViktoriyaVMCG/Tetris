module.exports = {
  board: require('./board'),
  scores: require('./scores'),
  session: require('./session')
};
